import os
import platform
import subprocess
import time
import sys
import dlxf
from datetime import datetime

sd = "shutdown.bat"
hn = "hibernate.bat"
rb = "reboot.bat"
pt = "powertest.bat"


def bat_tweeks():
    print("")
    print("\033[31mTHIS FEATURE IS NOT AVALIBLE YET!\033[0m")
    print("--- This can controll your PC! ---")
    print("------   (Windows only!)    ------")
    print("- hibernate: Hibernates pc.")
    print("- shutdown: Shuts down pc.")
    print("- reboot: Reboots pc.")
    print(
        "\033[31m- powertest: WARNING: it will open as much window as it can and slows down the pc!\033[0m"
    )
    print("- do nothing: exits this.")
    print("")
    user_input = input("the pc will ").strip().lower()
    if platform.system() == "Windows":
        if user_input == "hibernate":
            subprocess.run([hn], shell=True)
        else:
            print("\033[31mInput is not valid\033[0m")
    else:
        print("\033[31mNot windows! This command does't work on your OS!\033[0m")


def dinosaur():
    print("              __    ")
    print("             / _)   ")
    print("      .-^^^-/ /     ")
    print("   __/       /      ")
    print("  <__.|_|-|_|       ")


def cat():
    print("   /\_/\  ")
    print("  ( o.o ) ")
    print("   > ^ <  ")


def car():
    print("          _______            ")
    print("         //  ||\ \           ")
    print("   _____//___||_\ \___       ")
    print("   )  _          _    \      ")
    print("   |_/ \________/ \___|      ")
    print("  ___\_/________\_/______    ")


def clear():
    if platform.system() == "Windows":
        os.system("cls")
    else:
        os.system("clear")


def rick():
    file = open("rick", "r")
    for each in file:
        print(each.strip())
    file.close()

def bar(iteration, total, length=40):
    percent = (iteration / total) * 100
    filled_length = int(length * iteration // total)
    bar = '█' * filled_length + '-' * (length - filled_length)

    # Print the progress bar with ANSI colors
    sys.stdout.write(f"\r\033[32;44mProgress: |{bar}| {percent:.2f}%\033[0m")
    sys.stdout.flush()

def starting_text():
    print("\033[34m")
    file = open("logo", "r")
    for each in file:
        print(each.strip())
    file.close()
    print("\033[0m")

    print(" <Welcome to DMLinux! The best DM based linux!>")
    print(' <This "os" is running in your actual OS!>')
    print(" <Type 'help' if you are confused or you need any help!>")
    print()
    print()


morse_dict = {
    "a": ".-",
    "á": ".--.-",
    "ä": ".-.-",
    "b": "-...",
    "c": "-.-.",
    "d": "-..",
    "e": ".",
    "é": "..-..",
    "f": "..-.",
    "g": "--.",
    "h": "....",
    "i": "..",
    "j": ".---",
    "k": "-.-",
    "l": ".-..",
    "m": "--",
    "n": "-.",
    "o": "---",
    "ö": "---.",
    "p": ".--.",
    "q": "--.-",
    "r": ".-.",
    "s": "...",
    "t": "-",
    "u": "..-",
    "ü": "..--",
    "v": "...-",
    "w": ".--",
    "x": "-..-",
    "y": "-.--",
    "z": "--..",
    "1": ".----",
    "2": "..---",
    "3": "...--",
    "4": "....-",
    "5": ".....",
    "6": "-....",
    "7": "--...",
    "8": "---..",
    "9": "----.",
    "0": "-----",
    " ": "/",
    ".": "......",
    ",": ".-.-.-",
    ":": "---...",
    "?": "..--..",
    "!": "--..--",
    "-": "-....-",
    "(": "-.--.-",
    "/": "-..-.",
    "*": "-..-",
}


def convert(text):
    result = ""
    for letter in text:
        result = result + morse_dict[letter] + " "
    return result


def morse():
    user_input = input("translate: ").strip().lower()
    result = convert(user_input)
    print(result)


def help():
    print("")
    print(
        """
 \033[32m+------------------------------------+\033[0m
 \033[32m| \033[31m_    _   ______   _        _____   \033[32m|\033[0m
 \033[32m| \033[31m| |  | | |  ____| | |      |  __ \ \033[32m|\033[0m
 \033[32m| \033[31m| |__| | | |__    | |      | |__) |\033[32m|\033[0m
 \033[32m| \033[31m|  __  | |  __|   | |      |  ___/ \033[32m|\033[0m
 \033[32m| \033[31m| |  | | | |____  | |____  | |     \033[32m|\033[0m
 \033[32m| \033[31m|_|  |_| |______| |______| |_|     \033[32m|\033[0m
 \033[32m+------------------------------------+\033[0m
    """
    )
    print(" \033[32m-------------------------------------\033[0m ")
    print(" \033[32m|\033[0m exit: Exits and goes back.        \033[32m|\033[0m ")
    print(" \033[32m|\033[0m clear: Clears the terminal.       \033[32m|\033[0m ")
    print(" \033[32m|\033[0m art: Make an image of things.     \033[32m|\033[0m ")
    print(" \033[32m|\033[0m batt: batch files (windows).      \033[32m|\033[0m ")
    print(" \033[32m|\033[0m count: Count, countdown.          \033[32m|\033[0m ")
    print(" \033[32m|\033[0m morse: Translate text to morse.   \033[32m|\033[0m ")
    print(" \033[32m|\033[0m nano: Make a file.                \033[32m|\033[0m ")
    print(" \033[32m|\033[0m cat: Read a file.                 \033[32m|\033[0m ")
    print(" \033[32m|\033[0m time: Tells the current time.     \033[32m|\033[0m ")
    print(" \033[32m|\033[0m ls: Shows the list of files.      \033[32m|\033[0m ")
    print(" \033[32m|\033[0m cd: Changes the directory.        \033[32m|\033[0m ")
    print(" \033[32m|\033[0m pwd: Shows the current directory. \033[32m|\033[0m ")
    print(" \033[32m|\033[0m sysinfo: Shows some info.         \033[32m|\033[0m ")
    print(" \033[32m-------------------------------------\033[0m ")
    print("")


def art():
    print("What do you want to see:")
    print("1: Car")
    print("2: Cat")
    print("3: Dinosaur")
    print("4: ?????")
    user_input = input("choose 1-4! >").strip().lower()
    if user_input == "1":
        car()
    elif user_input == "2":
        cat()
    elif user_input == "3":
        dinosaur()
    elif user_input == "4":
        rick()
    else:
        print("\033[31mInput is not valid\033[0m")


def bye():
    print("Bye!")
    time.sleep(2)
    clear()


def count():
    print("Do you want to:")
    print("- count up")
    print("- count down")
    user_input = input("up/down >").strip().lower()
    if user_input == "up":
        user_input = int(input("seconds> ").strip())
        for i in range(user_input + 1):
            print(f"\r{i}", end="")
            time.sleep(1)

    elif user_input == "down":
        user_input = int(input("seconds> ").strip())  # Convert to integer
        for i in range(
            user_input, -1, -1
        ):  # Start from user_input, end at 0 (inclusive), step -1
            print(f"\r{i}", end="")
            sys.stdout.flush()
            time.sleep(1)
    else:
        print("\033[31mInput is not valid\033[0m")
