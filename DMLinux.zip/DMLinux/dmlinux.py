import dlx
import os
import platform
import subprocess
import time
import sys
import dlxf
from datetime import datetime

sd = "shutdown.bat"
hn = "hibernate.bat"
rb = "reboot.bat"
pt = "powertest.bat"

dlx.clear()
dlx.starting_text()
while True:
    try:
        user_input = input(">>>").strip().lower()

        if user_input == "help":
            dlx.help()
        elif user_input == "exit":
            break
        elif user_input == "morse":
            dlx.morse()
        elif user_input == "art":
            dlx.art()
        elif user_input == "clear":
            dlx.clear()
            dlx.starting_text()
        elif user_input == "count":
            dlx.count()
        elif user_input == "batt":
            dlx.bat_tweeks()
        elif user_input == "ls":
            dlxf.ls()
        elif user_input == "cd":
            user_input = input("Directory name>").strip().lower()
            dlxf.cd(user_input)
        elif user_input == "pwd":
            dlxf.pwd()
        elif user_input == "nano":
            dlxf.make()
        elif user_input == "cat":
            dlxf.read()
        elif user_input == "progressbar":
            milliseconds = 10000
            for i in range(milliseconds + 1):
                dlx.bar(i, milliseconds)
                time.sleep(0.001)
        elif user_input == "time":
            print(datetime.now())
        else:
            print(
                "Sorry, unknown command! Type 'help' if you are confused or you need any help!"
            )
    except Exception as e:
        print("\033[31mUnexpected error or Input is not valid.\033[0m")
        print("CLEARING")
        time.sleep(3)
        dlx.clear()
        dlx.starting_text()
dlx.bye()
