import dlx
import os
import platform
import subprocess
import time
import sys
from datetime import datetime

def make():
    user_input = input("file name> ").strip().lower()
    file = open(user_input, "w")
    user_input = input("input> ").strip().lower()
    file.write(user_input)
    file.close()


def read():
    user_input = input("file name> ").strip().lower()
    file = open(user_input, "r")
    for each in file:
        print(each.strip())
    file.close()

def ls(directory="."):
    try:
        items = os.listdir(directory)
        for item in items:
            print(item)
    except FileNotFoundError:
        print(f"The directory '{directory}' does not exist.")
    except PermissionError:
        print(f"Permission denied for accessing '{directory}'.")

def cd(path):
    try:
        os.chdir(path)
        print(f"\033[32mChanged directory to: {os.path.abspath(path)}\033[0m")
    except FileNotFoundError:
        print(f"\033[31mThe directory '{path}' does not exist.\033[0m")
    except NotADirectoryError:
        print(f"\033[31m'{path}' is not a directory.\033[0m")
    except PermissionError:
        print(f"\033[31mPermission denied for accessing '{path}'.\033[0m")


def pwd():
    print(f"Current directory: {os.getcwd()}")

